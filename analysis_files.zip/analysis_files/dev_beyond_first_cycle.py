#! /usr/bin/env python3

from scipy import stats

# in 7 cases situation after first cycle was better than at the end of proper development (excl. last drift)
print(stats.binom_test([7, 26]))
# p=0.00132
